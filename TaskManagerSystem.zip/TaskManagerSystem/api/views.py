from rest_framework import viewsets
from .models import TaskList, Task, Comment
from .serializers import TaskListSerializer, TaskSerializer, CommentSerializer
from rest_framework.permissions import IsAuthenticated, IsAdminUser
from rest_framework.authentication import TokenAuthentication
from rest_framework.decorators import action,api_view
from django.views.decorators.csrf import csrf_exempt
from django.db import IntegrityError
from django.http import JsonResponse
from rest_framework_simplejwt.tokens import RefreshToken
from django.contrib.auth import authenticate
from django.contrib.auth.models import User

def get_tokens_for_user(user):
    refresh = RefreshToken.for_user(user)

    return {
        'refresh': str(refresh),
        'access': str(refresh.access_token),
    }

@api_view(['POST'])
@csrf_exempt
def signup(request):
    if request.method == 'POST':
        try:
            data = request.data
            user = User.objects.create_user(data['username'], password=data['password'])
            user.save()
            tokens = get_tokens_for_user(user=user)
            return JsonResponse(tokens,status=201)
        except IntegrityError:
            return JsonResponse({'error':'That username has already been taken. Please choose a new username'},status=400)

@api_view(['POST'])
@csrf_exempt
def login(request):
    if request.method == 'POST':
        data = request.data
        user = authenticate(request,username=data['username'], password=data['password'])
        if user is None:
            return JsonResponse({'error':'Username or Password wrong'},status=401)
        else:
            tokens = get_tokens_for_user(user=user)
            return JsonResponse(tokens,status=200)

class TaskListViewSet(viewsets.ModelViewSet):
    queryset = TaskList.objects.all()
    serializer_class = TaskListSerializer
    permission_classes = [IsAuthenticated]

class TaskViewSet(viewsets.ModelViewSet):
    queryset = Task.objects.all()
    serializer_class = TaskSerializer
    permission_classes = [IsAuthenticated]

    @action(detail=True, methods=['post'])
    def complete(self, request, pk=None):
        task = self.get_object()
        task.completed = True
        task.save()
        return Response({'status': 'task marked as complete'})

class CommentViewSet(viewsets.ModelViewSet):
    queryset = Comment.objects.all()
    serializer_class = CommentSerializer
    permission_classes = [IsAuthenticated]
