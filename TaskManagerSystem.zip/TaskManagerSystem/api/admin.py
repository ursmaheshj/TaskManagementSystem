from django.contrib import admin
from api.models import Task,TaskList,Comment

# Register your models here.
admin.site.register(Task)
admin.site.register(TaskList)
admin.site.register(Comment)