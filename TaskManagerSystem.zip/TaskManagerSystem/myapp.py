import requests
import json

headers = {"Content-Type":'application/json'}
url = 'http://127.0.0.1:8000/api/signup'

def postdata():
    data={
        'username':'nikita',
        'password':'nikita',
    }
    r = requests.post(headers=headers, url=url, data=json.dumps(data))
    print(r.json())
    return r.json().get('access'),r.json().get('refresh')

access,refresh = postdata()
pprint(access,refresh)